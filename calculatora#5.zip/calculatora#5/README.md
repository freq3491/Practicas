# calculator-android-kotlin
<img src="plantilla2.png"/>
