
package com.example.dessertclicker.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple700 = Color(0xFF00574B)
val Pink600 = Color(0xFFD81B60)
val Green600 = Color(0xFF008577)